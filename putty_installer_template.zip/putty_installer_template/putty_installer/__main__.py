import os
import subprocess
import tempfile
import urllib.request


URL = "https://the.earth.li/~sgtatham/putty/latest/w64/putty.exe"


def main():
    exe = os.path.join(tempfile.gettempdir(), "putty.exe")

    if not os.path.exists(exe):
        print("Downloading PuTTY...")
        urllib.request.urlretrieve(URL, exe)

    print("Launching PuTTY...")
    subprocess.Popen([exe])


if __name__ == "__main__":
    main()